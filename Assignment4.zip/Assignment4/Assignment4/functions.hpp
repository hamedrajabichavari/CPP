//
//  functions.hpp
//  Assignment4
//
//  Created by Rajabi Chavari, Hamed on 2019-08-16.
//  Copyright © 2019 Rajabi Chavari, Hamed. All rights reserved.
//

#ifndef functions_hpp
#define functions_hpp

#include <stdio.h>
#include <string>
#pragma once
void creatRandomFile();
void addRecord();
void deleteRecord();
void searchRecord();
void modifyRecord();

#endif /* functions_hpp */
