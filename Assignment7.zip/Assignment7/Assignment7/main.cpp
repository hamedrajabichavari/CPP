//
//  main.cpp
//  Assignment7
//
//  Created by Rajabi Chavari, Hamed on 2019-08-28.
//  Copyright © 2019 Rajabi Chavari, Hamed. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctype.h>
#include <iomanip>
#include <sstream>
    
    class Complex{
        
    private:
        int real;
        int imaginary;
        
    public:
        Complex():real{0}, imaginary{0}{}
        
        Complex(int real,int imaginary): real{real}, imaginary{imaginary}{}
        Complex(int real): Complex(real,0){}
        
        Complex(const Complex &copyobj){
            this->real = copyobj.real;
            this->imaginary = copyobj.imaginary;
        }
        
        //setters & getters
        void setReal(int real){
            this->real = real;
        }
        void setImaginary(int imaginary){
            this->imaginary = imaginary;
        }
        int getReal(){
            return this->real;
        }
        int getImaginary(){
            return this->imaginary;
        }
        
        
        Complex operator +(const Complex &obj) const{
            return Complex(this->real + obj.real , this->imaginary + obj.imaginary);
        }
        Complex operator -(const Complex &obj) const{
            return Complex(this->real - obj.real , this->imaginary - obj.imaginary);
        }
        Complex operator *(const Complex &obj) const{
            return Complex((this->real * obj.real)-(this->imaginary * obj.imaginary) , (this->real * obj.imaginary)+(obj.real * this->imaginary));
        }
        Complex operator /(const Complex &obj) const{
            return Complex(((this->real * obj.real)+(this->imaginary * obj.imaginary))/(obj.real*obj.real - obj.imaginary*obj.imaginary) , (-(this->real * obj.real)+(obj.real * this->imaginary))/(obj.real*obj.real - obj.imaginary*obj.imaginary));
        }
        Complex &operator --(){
            this->real -=1;
            return *this;
        }

        Complex operator --(int){
            Complex temp = *this;
            -- *this;
            return temp;
        }
        
        Complex &operator ++(){
            this->real +=1;
            return *this;
        }
        
        Complex operator ++(int){
            Complex temp = *this;
            ++ *this;
            return temp;
        }
        
        bool operator == (const Complex &obj) const {
            return (this->real == obj.real && this->imaginary == obj.imaginary);
        }
        bool operator != (const Complex &obj) const {
            return !(*this == obj);
        }
        Complex operator =(const Complex &obj) const{
          
            return Complex(obj.real ,obj.imaginary);
        }

        
        
        ~Complex(){}
    

        ////output for Complex
        friend std::ostream & operator << (std::ostream & os , const Complex &obj){
            os << obj.real << " + " << obj.imaginary << "i" <<std::endl;
            return os;
        }

        //Input for Complex
        friend std::istream & operator >> (std::istream & is, Complex &obj) {
            is >> obj.real >> obj.imaginary;
            return is;
        }

    };
int main(){
        
    Complex a(5,2);
    Complex b(1,-4);
    
    std::cout <<"a + b = " << a+b << std::endl;
    std::cout << "a - b = " << a-b << std::endl;
    std::cout << "a * b = "<< a*b << std::endl;
    std::cout << "a / b = " << a/b << std::endl;
    std::cout <<"a-- " << a-- << std::endl;
    std::cout <<"a++ " << a++ << std::endl;
    
    if (a == b){
        std::cout << "a and b are the same" << std::endl;
    }else{
            std::cout << "a and b are not the same" << std::endl;
    }

    if (a != b){
        std::cout << "a and b are not the same" << std::endl;
    }else{
            std::cout << "a and b are the same" << std::endl;
    }
            
//            Complex d;
//            std::cout << "provide real , imaginary " << std::endl;
//            std::cin >> d;
//            std::cout << d << std::endl;
    
}

