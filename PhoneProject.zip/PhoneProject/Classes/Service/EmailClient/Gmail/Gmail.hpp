//
//  Gmail.hpp
//  PhoneProject
//
//  Created by Saygin Guven on 2019-08-22.
//

#ifndef Gmail_hpp
#define Gmail_hpp

#include <stdio.h>
#include <iostream>
#include "../EmailClient.hpp"

//create properties
//getters and setters
//constructors (default, overloaded, copy)
//destructor
//methods
class Gmail : public EmailClient{
    
private:
    
protected:
    
public:
    void test(){std::cout <<"gmail test";}
};

#endif /* Gmail_hpp */
