//
//  main.cpp
//  PhoneProject
//
//  Created by Saygin Guven on 2019-08-22.
//

#include <iostream>
#include "../Classes/all_headers.hpp"
#include <vector>

int main() {

    Phone phone;
    Camera camera;
    VideoCamera videoCamera;
    PictureCamera pictureCamera;
    Player player;
    MusicPlayer musicPlayer;
    VideoPlayer videoPlayer;
    Message message;
    Calculator calculator;
    ApplicationCenter applicationCenter;
    WebBrowser webBrowser;
    Calendar calendar;
    EmailClient emailClient;
    Gmail gmail;
    
    //dynamic binding
    std::cout<<"dynamic binding" <<std::endl;
    Service * services[14];
    services[0]= &phone;
    services[1]= &camera;
    services[2]= &videoCamera;
    services[3]= &pictureCamera;
    services[4]= &player;
    services[5]= &musicPlayer;
    services[6]= &videoPlayer;
    services[7]= &message;
    services[8]= &calculator;
    services[9]= &applicationCenter;
    services[10]= &webBrowser;
    services[11]= &calendar;
    services[12]= &emailClient;
    services[13]= &gmail;
    
    for(auto Service : services)
        std::cout << Service->ServiceName() << std::endl;
    
    std::cout << "----------------" << std::endl;
    std::cout << "phone volume is : " << phone.SetVoiceVolume(5)<<std::endl;
    std::cout << "phone volume is : " << phone.SetVoiceVolume(12)<<std::endl;
    std::cout << "phone volume is : " << phone.SetVoiceVolume(-4)<<std::endl;
    std::cout << "----------------" << std::endl;
    
    
    
//    Phone phone;
    //    std::cout << phone.ServiceName()<<std::endl;
 
    //    VideoCamera camera;
    //    std::cout << camera.OpenCamera() << std::endl;
    
    //    std::cout << std::boolalpha << camera.Record()<<std::endl;
    //    std::cout << std::boolalpha << camera.StopRecording()<<std::endl;
    //
    //    Player player;
    //    std::cout << std::boolalpha << player.Play()<<std::endl;
    //    std::cout << std::boolalpha << player.StopPlaying()<<std::endl;
    //
    //    Calculator calculator;
    //    std::cout << calculator.Add(2,5)<<std::endl;
    //    // insert code here...
    //    std::cout << "Good Luck" << std::endl;
    
    
    return 0;
}
