//
//  main.cpp
//  PhoneProject
//
//  Created by Saygin Guven on 2019-08-22.
//

#include <iostream>
#include "../Classes/all_headers.hpp"

int main() {

//    Phone Iphone;
//    std::cout << Iphone.ServiceName()<<std::endl;
    VideoCamera camera;
    std::cout << camera.OpenCamera() << std::endl;
    
    std::cout << std::boolalpha << camera.Record()<<std::endl;
    std::cout << std::boolalpha << camera.StopRecording()<<std::endl;
    
    Player Player;
    std::cout << std::boolalpha << Player.Play()<<std::endl;
    std::cout << std::boolalpha << Player.StopPlaying()<<std::endl;
    
    
    Calculator calculator;
    std::cout << calculator.Add(2,5)<<std::endl;
    // insert code here...
    std::cout << "Good Luck" << std::endl;
    
   
    return 0;
}
